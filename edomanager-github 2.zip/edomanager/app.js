const chats = [
  {
    id: "alina", name: "Алина", handle: "@alina", avatar: "A", bio: "Дизайн, музыка и хорошие идеи.",
    color: "linear-gradient(145deg,#8b5cf6,#4b6cff)", time: "16:39", unread: 2,
    messages: [
      {from:"them", text:"Привет! Ты уже посмотрел новый макет?", time:"16:34"},
      {from:"me", text:"Да, только что открыл. Выглядит очень чисто 🔥", time:"16:35"},
      {from:"them", text:"Супер. Я ещё чуть-чуть поправлю карточки.", time:"16:36"},
      {from:"me", text:"Ок, кидай финальную версию сюда.", time:"16:38"},
      {from:"them", text:"Уже отправляю ✨", time:"16:39"}
    ]
  },
  {
    id: "max", name: "Максим", handle: "@maxdev", avatar: "M", bio: "Frontend / backend / coffee.",
    color: "linear-gradient(145deg,#f59e0b,#ef4444)", time: "15:12", unread: 0,
    messages: [
      {from:"them", text:"Сервер поднял. Можешь проверять.", time:"15:09"},
      {from:"me", text:"Отлично, сейчас гляну.", time:"15:12"}
    ]
  },
  {
    id: "team", name: "Команда edomanager", handle: "@edomanager", avatar: "e", bio: "Рабочая группа проекта.",
    color: "linear-gradient(145deg,#14b8a6,#2563eb)", time: "Вчера", unread: 5,
    messages: [
      {from:"them", text:"Всем привет! Сегодня закрываем релиз.", time:"Вчера"},
      {from:"me", text:"Принято. Я беру на себя интерфейс.", time:"Вчера"}
    ]
  },
  {
    id: "nika", name: "Ника", handle: "@nika", avatar: "N", bio: "Фото, путешествия и коты.",
    color: "linear-gradient(145deg,#ec4899,#f97316)", time: "Пн", unread: 0,
    messages: [{from:"them", text:"Посмотри, какое фото получилось 😄", time:"Пн"}]
  }
];

let activeId = "alina";
let dark = true;

const $ = s => document.querySelector(s);
const chatList = $("#chatList"), messages = $("#messages");

function renderChats(filter=""){
  chatList.innerHTML = "";
  chats.filter(c => c.name.toLowerCase().includes(filter.toLowerCase()) || c.handle.includes(filter.toLowerCase()))
    .forEach(c => {
      const last = c.messages[c.messages.length-1];
      const el = document.createElement("div");
      el.className = `chat-item ${c.id===activeId ? "active":""}`;
      el.innerHTML = `
        <div class="avatar" style="background:${c.color}">${c.avatar}</div>
        <div class="chat-meta">
          <div class="chat-top"><strong>${c.name}</strong><span class="chat-time">${c.time}</span></div>
          <div class="preview">${last.text}${c.unread ? `<span class="unread">${c.unread}</span>`:""}</div>
        </div>`;
      el.onclick = () => selectChat(c.id);
      chatList.appendChild(el);
    });
}

function selectChat(id){
  activeId = id;
  const c = chats.find(x => x.id === id);
  if(!c) return;
  c.unread = 0;
  $("#headerName").textContent = c.name;
  $("#headerAvatar").textContent = c.avatar;
  $("#headerAvatar").style.background = c.color;
  $("#detailsAvatar").textContent = c.avatar;
  $("#detailsAvatar").style.background = c.color;
  $("#detailsName").textContent = c.name;
  $("#detailsHandle").textContent = c.handle;
  $("#detailsBio").textContent = c.bio;
  renderMessages();
  renderChats($("#searchInput").value);
}

function renderMessages(){
  const c = chats.find(x => x.id === activeId);
  messages.innerHTML = "";
  c.messages.forEach(m => {
    const row = document.createElement("div");
    row.className = `message-row ${m.from === "me" ? "me":""}`;
    row.innerHTML = `<div class="message-bubble"><div class="message-text">${escapeHtml(m.text)}</div><div class="message-time">${m.time}${m.from==="me" ? "  ✓✓":""}</div></div>`;
    messages.appendChild(row);
  });
  setTimeout(()=>{ const box = $(".messages-wrap"); box.scrollTop = box.scrollHeight; },0);
}

function sendMessage(){
  const input = $("#messageInput");
  const text = input.value.trim();
  if(!text) return;
  const c = chats.find(x => x.id === activeId);
  const now = new Date();
  const time = now.toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"});
  c.messages.push({from:"me", text, time});
  c.time = time;
  input.value = "";
  renderMessages();
  renderChats($("#searchInput").value);
  setTimeout(()=>{
    if(activeId !== c.id) return;
    c.messages.push({from:"them", text:"Принято 👌", time});
    c.time = time;
    renderMessages();
    renderChats($("#searchInput").value);
  }, 900);
}

function escapeHtml(s){
  return s.replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));
}
function toast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>t.classList.remove("show"),1800);
}

$("#sendBtn").onclick=sendMessage;
$("#messageInput").addEventListener("keydown", e=>{
  if(e.key==="Enter" && !e.shiftKey){e.preventDefault();sendMessage();}
});
$("#searchInput").addEventListener("input", e=>renderChats(e.target.value));
$("#newChatBtn").onclick=()=>toast("Создание нового чата — подключите backend для сохранения пользователей.");
$("#themeBtn").onclick=()=>toast("Тёмная тема активна.");
$("#logoutBtn").onclick=()=>toast("Выход из демо-режима.");
document.addEventListener("keydown", e=>{
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==="k"){e.preventDefault();$("#searchInput").focus();}
});
selectChat(activeId);
